<?php
include '../config.php';
checkiflogged($_SESSION);
$siteconfig = getsiteconfig();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="A layout example with a side menu that hides on mobile, just like the Pure website.">
<title><?php echo $siteconfig['site_name'];?></title>
<?php
include 'include/head.php';
?>
</head>
<body>
<div id="layout">
<!-- Menu toggle -->
<a href="#menu" id="menuLink" class="menu-link">
<!-- Hamburger icon -->
<span></span>
</a>
<?php
include 'include/sidebar.php';
?>
<div id="main">
<div class="header">
<h1>Welcome</h1>
</div>
<div class="content">
<h2 class="content-subhead">Hello <?php echo $_SESSION['logged_in']['name'];?></h2>
<?php
if($_SESSION['logged_in']['type']=='admin'){
?>
<h3>Open Source Multisite Website Builder PHP Script</h3>

<a class="button" href="https://www.codester.com/items/483/html5-multiple-website-builder-php-script" >PURCHASE FULL VERSION</a>

<div id="main">

					<!-- One -->
						<section id="one">
							<div class="container">
								<header class="major">
									<h2>HTML5 Multiple Website Builder - Responsive Multisite CMS</h2>
									<p>PHP/MySQL multiple mobile friendly website builder. Just what you need to create multiple CMS driven responsive websites in few clicks</p>
								</header>
							
							
							
							</div>
						</section>
						
					<!-- Two -->
						<section id="two">
							<div class="container">
							
								
									<header class="major">
									<h2>Features</h2>
									<h4>User friendly theme editor: No coding required</h4>
									<img src="img/one.jpg" />
									<hr>
									<h4>Multiple pre-made Themes to chose from</h4>
									<img src="img/two.jpg" />
									<hr>
									<h4>CMS Driven - Add, edit, delete content with a few clicks</h4>
									<img src="img/three.jpg" />
									<hr>
									<h4>Google Map pointing exactly where your business is located</h4>
									<img src="img/four.jpg" />
									<hr>
									<h4>Product Catalog - Unlimited amount of category and products</h4>
									<img src="img/five.jpg" />
									<hr>
									<h4>Multiple pages - Add unlimited amount of rich content pages</h4>
									<img src="img/six.jpg" />
									<hr>
									<h4>Image Gallery</h4>
										<img src="img/seven.jpg" />
									<hr>
									<h4>Contact Us form</h4>
										<img src="img/eight.jpg" />
									<hr>
								</header>
								
								
					
						</div>
						</section>

					<!-- Two -->
						<section id="three">
							<div class="container">
				<header class="major">
								<h2>DEMO</h2>
								</header>
								<h4><a target="_blank" href="http://html5multiplewebsitebuilder.ml/demo/">DEMO - Website builder</a></h4>
<h4><a target="_blank" href="http://html5multiplewebsitebuilder.ml/demo/about-us">DEMO - Website builder clients</a></h4>
								<h4><a target="_blank" href="http://html5multiplewebsitebuilder.ml/demo/sample-furniture-shop/">DEMO - Client website 1</a></h4>
						<h4><a target="_blank" href="http://html5multiplewebsitebuilder.ml/demo/sample-furniture-shop/products/1/bedrooms">DEMO - Product Catalogue</a></h4>
					<h4><a target="_blank" href="http://html5multiplewebsitebuilder.ml/demo/sample-furniture-shop/product_detail/1/peace-purple-bedroom">DEMO - Product Detail page</a></h4>
					<h4><a target="_blank" href="http://html5multiplewebsitebuilder.ml/demo/sample-beauty-salon/">DEMO - Client website 2</a></h4>
					
					<br>	
			





<hr>


				</div>
						</section>
					
				
				</div>
<a class="button" href="https://www.codester.com/items/483/html5-multiple-website-builder-php-script" >PURCHASE FULL VERSION</a>
<p>&nbsp;</p>
<?php
}else{
echo $siteconfig['admin_text'];
}
?>
</div>
</div>
</div>
<script src="<?php echo ROOT_WWW;?>admin/js/ui.js"></script>
</body>
</html>
