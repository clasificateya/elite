<header id="navtop"> <a href="<?php echo ROOT_WWW;?>" class="logo fleft"><h2><?php echo $siteconfig['site_name'];?></h2></a>
    <nav class="fright">
      <ul>
        <li><a href="<?php echo ROOT_WWW;?>" class="navactive"><i class="fa fa-home fa-lg"></i> Home</a></li>
      </ul>
      <ul>
        <li><a href="<?php echo ROOT_WWW;?>about-us"><i class="fa fa-briefcase fa-lg"></i> Our work</a></li>
      </ul>
	  <ul>
        <li><a href="<?php echo ROOT_WWW;?>register"><i class="fa fa-magic"></i> Sign Up Free</a></li>
      </ul>
	  <ul>
        <li><a href="<?php echo ROOT_WWW;?>contact-us"><i class="fa fa-envelope fa-lg"></i> Contact us</a></li>
      </ul>
    </nav>
  </header>